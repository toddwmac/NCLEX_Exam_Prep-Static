from flask import Flask, render_template, request, jsonify, send_from_directory
import json
import markdown
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this in production

# Question bank
QUESTIONS = {
    'med-surg': [
        {
            'id': 'ms1',
            'question': 'A client with COPD is receiving oxygen therapy at 2 L/min via nasal cannula. Which assessment finding would indicate the therapy is effective?',
            'options': [
                'Oxygen saturation of 88%',
                'Respiratory rate of 28 breaths/min',
                'Oxygen saturation of 95%',
                'Use of accessory muscles'
            ],
            'correct': 2,  # Index of correct answer (0-based)
            'explanation': 'An oxygen saturation of 95% indicates effective oxygen therapy. For COPD patients, target saturation is typically 88-92%, but higher values are acceptable if the patient is stable.'
        },
        {
            'id': 'ms2',
            'question': 'A client with diabetes mellitus has a blood glucose level of 45 mg/dL. Which intervention should the nurse implement first?',
            'options': [
                'Administer glucagon IM',
                'Give 15g of fast-acting carbohydrate',
                'Call the healthcare provider',
                'Check vital signs'
            ],
            'correct': 1,
            'explanation': 'For conscious patients with hypoglycemia, the first intervention is to provide 15g of fast-acting carbohydrate (like juice or glucose tablets), then recheck blood glucose in 15 minutes.'
        }
    ],
    'pediatrics': [
        {
            'id': 'ped1',
            'question': 'A 2-year-old child presents with a fever of 103°F (39.4°C). Which intervention should the nurse implement first?',
            'options': [
                'Administer acetaminophen as prescribed',
                'Apply a cold compress to the forehead',
                'Encourage increased fluid intake',
                'Place the child in a lukewarm bath'
            ],
            'correct': 0,
            'explanation': 'The first intervention for a high fever should be to administer antipyretic medication as prescribed. This helps reduce fever and provides comfort to the child.'
        },
        {
            'id': 'ped2',
            'question': 'Which finding in a 6-month-old infant would indicate normal development?',
            'options': [
                'Walks with assistance',
                'Sits without support',
                'Speaks in two-word sentences',
                'Feeds self with spoon'
            ],
            'correct': 1,
            'explanation': 'At 6 months, sitting without support is a normal developmental milestone. Walking, speaking in sentences, and self-feeding with utensils come at later stages.'
        }
    ],
    'mental-health': [
        {
            'id': 'mh1',
            'question': 'A client with depression states, "I just want to end it all." What is the nurse\'s best initial response?',
            'options': [
                'Don\'t talk like that; things will get better.',
                'Are you having thoughts of hurting yourself?',
                'Let me call your family right away.',
                'You need to think more positively.'
            ],
            'correct': 1,
            'explanation': 'The best initial response is to directly assess suicide risk by asking about self-harm thoughts. This shows you take the client seriously and allows for proper assessment.'
        },
        {
            'id': 'mh2',
            'question': 'A client with schizophrenia reports that the TV is sending special messages. Which response by the nurse is most therapeutic?',
            'options': [
                'That must be frightening for you.',
                'The TV isn\'t really sending you messages.',
                'Let\'s watch something else.',
                'Who else knows about these messages?'
            ],
            'correct': 0,
            'explanation': 'Acknowledging the client\'s feelings without reinforcing or challenging the delusion is most therapeutic. This builds trust while maintaining a reality-based relationship.'
        }
    ],
    'maternal': [
        {
            'id': 'mat1',
            'question': 'A primigravida in active labor has contractions every 3 minutes. Which finding indicates that labor is progressing normally?',
            'options': [
                'Cervical dilation decreasing',
                'Contractions becoming irregular',
                'Cervical dilation of 1 cm per hour',
                'Fetal station remaining at -2'
            ],
            'correct': 2,
            'explanation': 'Normal labor progression in the active phase is characterized by cervical dilation of approximately 1 cm per hour in primigravidas.'
        },
        {
            'id': 'mat2',
            'question': 'Which assessment finding in a 2-hour-old newborn requires immediate nursing intervention?',
            'options': [
                'Respiratory rate of 40 breaths/min',
                'Axillary temperature of 98.6°F (37°C)',
                'Heart rate of 180 beats/min',
                'Clear lung sounds bilaterally'
            ],
            'correct': 2,
            'explanation': 'A heart rate of 180 beats/min in a newborn is tachycardia and requires immediate attention. Normal newborn heart rate is 120-160 beats/min.'
        }
    ],
    'pharmacology': [
        {
            'id': 'pharm1',
            'question': 'A client is prescribed warfarin (Coumadin). Which food should the nurse teach the client to avoid?',
            'options': [
                'Bananas',
                'Green leafy vegetables',
                'Lean meats',
                'White bread'
            ],
            'correct': 1,
            'explanation': 'Green leafy vegetables are high in vitamin K, which antagonizes the anticoagulant effect of warfarin. Clients should maintain consistent vitamin K intake.'
        },
        {
            'id': 'pharm2',
            'question': 'A client taking furosemide (Lasix) requires which laboratory value to be monitored most closely?',
            'options': [
                'Potassium',
                'Calcium',
                'Magnesium',
                'Phosphorus'
            ],
            'correct': 0,
            'explanation': 'Furosemide is a loop diuretic that causes increased potassium excretion, potentially leading to hypokalemia. Potassium levels must be monitored closely.'
        }
    ],
    'leadership': [
        {
            'id': 'lead1',
            'question': 'Which task is most appropriate for the charge nurse to delegate to a licensed practical nurse (LPN)?',
            'options': [
                'Initial patient assessment',
                'Care plan development',
                'Medication administration',
                'Patient teaching'
            ],
            'correct': 2,
            'explanation': 'LPNs can safely administer most medications within their scope of practice. Initial assessments, care planning, and patient teaching are typically RN responsibilities.'
        },
        {
            'id': 'lead2',
            'question': 'A nurse observes a colleague making a medication error. What is the first action the nurse should take?',
            'options': [
                'Report the colleague to the nurse manager',
                'Document the error in the incident report',
                'Ensure the patient\'s safety',
                'Notify the physician'
            ],
            'correct': 2,
            'explanation': 'The first priority is always patient safety. After ensuring the patient is safe, the error should be reported and documented according to facility policy.'
        }
    ]
}

def load_study_guide(guide_name):
    # Try HTML file first
    html_path = os.path.join('static', 'content', 'study-guides', f'{guide_name}.html')
    if os.path.exists(html_path):
        with open(html_path, 'r', encoding='utf-8') as file:
            return file.read()
    
    # Fall back to markdown file
    md_path = os.path.join('static', 'content', 'study-guides', f'{guide_name}.md')
    if os.path.exists(md_path):
        with open(md_path, 'r', encoding='utf-8') as file:
            content = file.read()
            # Convert Markdown to HTML
            html_content = markdown.markdown(content, extensions=['fenced_code', 'tables'])
            return html_content
    return None

def load_quick_reference(reference_name):
    file_path = os.path.join('static', 'content', 'quick-reference', f'{reference_name}.json')
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    return None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/practice')
def practice():
    topic = request.args.get('topic')
    if topic and topic in QUESTIONS:
        return render_template('question.html', topic=topic, questions=QUESTIONS[topic])
    return render_template('practice.html')

@app.route('/materials')
def materials():
    return render_template('materials.html')

@app.route('/materials/study-guide/<guide_name>')
def study_guide(guide_name):
    content = load_study_guide(guide_name)
    if content:
        return render_template('study_guide.html', content=content, guide_name=guide_name)
    return "Study guide not found", 404

@app.route('/materials/quick-reference/<reference_name>')
def quick_reference(reference_name):
    content = load_quick_reference(reference_name)
    if content:
        return render_template('quick_reference.html', content=content, reference_name=reference_name)
    return "Reference material not found", 404

@app.route('/progress')
def progress():
    return render_template('progress.html')

if __name__ == '__main__':
    app.run(debug=True) 